const { create, Client } = require('@open-wa/wa-automate')
const figlet = require('figlet')
const options = require('./utils/options')
const { color, messageLog } = require('./utils')
const HandleMsg = require('./HandleMsg')

const start = (thunderx = new Client()) => {
    console.log(color(figlet.textSync('----------------', { horizontalLayout: 'default' })))
    console.log(color(figlet.textSync('THUNDERbot', { font: 'Ghost', horizontalLayout: 'default' })))
    console.log(color(figlet.textSync('----------------', { horizontalLayout: 'default' })))
    console.log(color('[DEV]'), color('THUNDERX', 'yellow'))
    console.log(color('[~>>]'), color('BOT Started!', 'green'))

    // Mempertahankan sesi agar tetap nyala
    thunderx.onStateChanged((state) => {
        console.log(color('[~>>]', 'red'), state)
        if (state === 'CONFLICT' || state === 'UNLAUNCHED') thunderx.forceRefocus()
    })

    // ketika bot diinvite ke dalam group
    thunderx.onAddedToGroup(async (chat) => {
	const groups = await thunderx.getAllGroups()
	// kondisi ketika batas group bot telah tercapai,ubah di file settings/setting.json
	if (groups.length > groupLimit) {
	await thunderx.sendText(chat.id, `Sorry, the group on this bot is full\nMax Group is: ${groupLimit}`).then(() => {
	      thunderx.leaveGroup(chat.id)
	      thunderx.deleteChat(chat.id)
	  }) 
	} else {
	// kondisi ketika batas member group belum tercapai, ubah di file settings/setting.json
	    if (chat.groupMetadata.participants.length < memberLimit) {
	    await thunderx.sendText(chat.id, `Sorry, BOT comes out if the group members do not exceed ${memberLimit} people`).then(() => {
	      thunderx.leaveGroup(chat.id)
	      thunderx.deleteChat(chat.id)
	    })
	    } else {
        await thunderx.simulateTyping(chat.id, true).then(async () => {
          await thunderx.sendText(chat.id, `Hai minna~, Im thunderx BOT. To find out the commands on this bot type ${prefix}menu`)
        })
	    }
	}
    })

    // ketika seseorang masuk/keluar dari group
    thunderx.onGlobalParicipantsChanged(async (event) => {
        const host = await thunderx.getHostNumber() + '@c.us'
        // kondisi ketika seseorang diinvite/join group lewat link
        if (event.action === 'add' && event.who !== host) {
            await thunderx.sendTextWithMentions(event.chat, `Hello, Welcome to the group @${event.who.replace('@c.us', '')} \n\nHave fun with us✨`)
        }
        // kondisi ketika seseorang dikick/keluar dari group
        if (event.action === 'remove' && event.who !== host) {
            await thunderx.sendTextWithMentions(event.chat, `Good bye @${event.who.replace('@c.us', '')}, We'll miss you✨`)
        }
    })

    thunderx.onIncomingCall(async (callData) => {
        // ketika seseorang menelpon nomor bot akan mengirim pesan
        await thunderx.sendText(callData.peerJid, 'Maaf sedang tidak bisa menerima panggilan.\n\n-bot')
        .then(async () => {
            // bot akan memblock nomor itu
            await thunderx.contactBlock(callData.peerJid)
        })
    })

    // ketika seseorang mengirim pesan
    thunderx.onMessage(async (message) => {
        thunderx.getAmountOfLoadedMessages() // menghapus pesan cache jika sudah 10000 pesan.
            .then((msg) => {
                if (msg >= 10000) {
                    console.log('[thunderx]', color(`Loaded Message Reach ${msg}, cuting message cache...`, 'yellow'))
                    thunderx.cutMsgCache()
                }
            })
        HandleMsg(thunderx, message)    
    
    })
	
    // Message log for analytic
    thunderx.onAnyMessage((anal) => { 
        messageLog(anal.fromMe, anal.type)
    })
}

//create session
create(options(true, start))
    .then((thunderx) => start(thunderx))
    .catch((err) => new Error(err))
